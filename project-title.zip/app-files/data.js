var APP_DATA = {
  "scenes": [
    {
      "id": "0-r0010106",
      "name": "R0010106",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1680,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.03178573669896423,
          "pitch": 0.25432361502709355,
          "rotation": 0,
          "target": "1-r0010107"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-r0010107",
      "name": "R0010107",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1680,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -3.027773483205662,
          "pitch": 0.5497857282824601,
          "rotation": 0,
          "target": "0-r0010106"
        },
        {
          "yaw": -0.01945415312337495,
          "pitch": 0.28759790396957285,
          "rotation": 0,
          "target": "2-r0010108"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-r0010108",
      "name": "R0010108",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1680,
      "initialViewParameters": {
        "yaw": 0.05069200568717491,
        "pitch": 0.09892058362652278,
        "fov": 1.3333127936580627
      },
      "linkHotspots": [
        {
          "yaw": -3.09587269598493,
          "pitch": 0.3810470046072094,
          "rotation": 0,
          "target": "1-r0010107"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": false
  }
};
